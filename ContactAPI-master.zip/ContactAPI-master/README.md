# ContactAPI


Get:
http://localhost:8081/api/Contacts?FName=vali

Post:
http://localhost:8081/api/Contacts
Give below Json in Body

GetByID
http://localhost:8081/api/Contacts/2

PutByID
http://localhost:8081/api/Contacts/1
Give Below Json in Body

DeleteByID
http://localhost:8081/api/Contacts/2

Json Example

{
	"Identification": {
		"FirstName": "Bob",
		"LastName": "Frederick",
		"DOB": "06/21/1980",
		"Gender": "M",
		"Title": "Manager"
  },
	"Address": [{
		"type ": "home",
		"number": 1234,
		"street": "blah blah St",
		"Unit": "1 a",
		"City": "Somewhere",
		"State": "WV",
		"zipcode": "12345"
	}],
	"Communication": [{
			"type": "email",
			"value": "bfe@sample.com",
	  		"preferred" : "true"
		},
		{
			"type": "cell",
			"value": "304-555-8282"
		}
	]

}
